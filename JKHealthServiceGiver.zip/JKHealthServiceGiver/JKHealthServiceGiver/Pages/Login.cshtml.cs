using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace JKHealthServiceGiver.Pages
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public LoginInput Input { get; set; } = new LoginInput();

        public class LoginInput
        {
            public string Email { get; set; }
            public string Password { get; set; }
        }

        public void OnGet() { }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
                return Page();

            // Handle login logic here...

            return RedirectToPage("Welcome");
        }
    }
}
