using Microsoft.AspNetCore.Mvc.RazorPages;

namespace JKHealthServiceGiver.Pages
{
    public class WelcomeModel : PageModel
    {
        public void OnGet()
        {
            // Any logic for the Welcome page can go here.
        }
    }
}
