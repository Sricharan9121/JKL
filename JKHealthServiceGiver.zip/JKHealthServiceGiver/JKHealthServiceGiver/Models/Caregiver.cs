﻿namespace JKHealthServiceGiver.Models
{
    public class Caregiver
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsAvailable { get; set; }
    }
}