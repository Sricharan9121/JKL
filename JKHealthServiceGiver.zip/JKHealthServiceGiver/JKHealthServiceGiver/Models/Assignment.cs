﻿namespace JKHealthServiceGiver.Models
{
    public class Assignment
    {
        public int Id { get; set; }
        public string CaregiverName { get; set; }
        public string PatientName { get; set; }
    }
}
