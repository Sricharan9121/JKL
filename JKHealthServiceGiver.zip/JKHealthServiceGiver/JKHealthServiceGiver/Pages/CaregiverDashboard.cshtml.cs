using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Data.SqlClient;
using JKHealthServiceGiver.Models;

namespace JKHealthServiceGiver.Pages
{
    public class CaregiverDashboardModel : PageModel
    {
        private readonly string _connectionString = "Data Source=DESKTOP-QAPCFG3\\SQLEXPRESS;Initial Catalog=healthserviceprovider;Integrated Security=True";

        public List<Caregiver> Caregivers { get; set; } = new List<Caregiver>();
        public List<Patient> Patients { get; set; } = new List<Patient>();
        public List<Assignment> Assignments { get; set; } = new List<Assignment>();

        public void OnGet()
        {
            // Fetch caregivers
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Caregivers", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Caregivers.Add(new Caregiver
                    {
                        Id = (int)reader["Id"],
                        Name = reader["Name"].ToString(),
                        IsAvailable = (bool)reader["IsAvailable"]
                    });
                }
            }

            // Fetch patients
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Patients", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Patients.Add(new Patient
                    {
                        Id = (int)reader["Id"],
                        Name = reader["Name"].ToString()
                    });
                }
            }

            // Fetch ongoing assignments
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(@"
                    SELECT a.Id, c.Name AS CaregiverName, p.Name AS PatientName 
                    FROM Assignments a 
                    JOIN Caregivers c ON a.CaregiverId = c.Id 
                    JOIN Patients p ON a.PatientId = p.Id", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Assignments.Add(new Assignment
                    {
                        Id = (int)reader["Id"],
                        CaregiverName = reader["CaregiverName"].ToString(),
                        PatientName = reader["PatientName"].ToString()
                    });
                }
            }
        }

        public IActionResult OnPostAssign(int CaregiverId, int PatientId)
        {
            // Assign caregiver to patient
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Assignments (CaregiverId, PatientId) VALUES (@CaregiverId, @PatientId)", conn);
                cmd.Parameters.AddWithValue("@CaregiverId", CaregiverId);
                cmd.Parameters.AddWithValue("@PatientId", PatientId);
                cmd.ExecuteNonQuery();

                // Mark caregiver as unavailable
                SqlCommand updateCmd = new SqlCommand("UPDATE Caregivers SET IsAvailable = 0 WHERE Id = @CaregiverId", conn);
                updateCmd.Parameters.AddWithValue("@CaregiverId", CaregiverId);
                updateCmd.ExecuteNonQuery();
            }
            return RedirectToPage();
        }

        public IActionResult OnPostRemove(int AssignmentId)
        {
            // Remove caregiver assignment
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM Assignments WHERE Id = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", AssignmentId);
                cmd.ExecuteNonQuery();

                // Update caregiver availability
                SqlCommand updateCmd = new SqlCommand(@"
                    UPDATE Caregivers 
                    SET IsAvailable = 1 
                    WHERE Id = (SELECT CaregiverId FROM Assignments WHERE Id = @Id)", conn);
                updateCmd.Parameters.AddWithValue("@Id", AssignmentId);
                updateCmd.ExecuteNonQuery();
            }
            return RedirectToPage();
        }
    }

  

  
}
