using JKHealthServiceGiver.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace JKHealthServiceGiver.Pages
{
    public class AppointmentScheduleDashboardModel : PageModel
    {
        private readonly string _connectionString = "Data Source=DESKTOP-QAPCFG3\\SQLEXPRESS;Initial Catalog=healthserviceprovider;Integrated Security=True";

        // Lists to store caregivers, patients, and appointments
        public List<Caregiver> Caregivers { get; set; } = new List<Caregiver>();
        public List<Patient> Patients { get; set; } = new List<Patient>();
        public List<Appointment> Appointments { get; set; } = new List<Appointment>();
        public List<AppointmentNotification> Notifications { get; set; } = new List<AppointmentNotification>();

        // OnGet method to fetch caregivers, patients, appointments, and notifications
        public void OnGet()
        {
            // Fetch caregivers from the database
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Caregivers", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Caregivers.Add(new Caregiver
                    {
                        Id = (int)reader["Id"],
                        Name = reader["Name"].ToString(),
                        IsAvailable = (bool)reader["IsAvailable"]
                    });
                }
            }

            // Fetch patients from the database
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Patients", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Patients.Add(new Patient
                    {
                        Id = (int)reader["Id"],
                        Name = reader["Name"].ToString()
                    });
                }
            }

            // Fetch appointments from the database
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(@"
                    SELECT a.Id, c.Name AS CaregiverName, p.Name AS PatientName, a.AppointmentDate, a.Status 
                    FROM Appointments a 
                    JOIN Caregivers c ON a.CaregiverId = c.Id 
                    JOIN Patients p ON a.PatientId = p.Id", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Appointments.Add(new Appointment
                    {
                        Id = (int)reader["Id"],
                        CaregiverName = reader["CaregiverName"].ToString(),
                        PatientName = reader["PatientName"].ToString(),
                        AppointmentDate = (DateTime)reader["AppointmentDate"],
                        Status = reader["Status"].ToString()
                    });
                }
            }

            // Fetch appointment notifications
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(@"
                    SELECT n.NotificationMessage, n.CreatedAt, a.CaregiverId, a.PatientId 
                    FROM AppointmentNotifications n
                    JOIN Appointments a ON n.AppointmentId = a.Id", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Notifications.Add(new AppointmentNotification
                    {
                        NotificationMessage = reader["NotificationMessage"].ToString(),
                        CreatedAt = (DateTime)reader["CreatedAt"]
                    });
                }
            }
        }

        // OnPost method to schedule a new appointment
        public IActionResult OnPostSchedule(int CaregiverId, int PatientId, DateTime AppointmentDate)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                // Insert new appointment into Appointments table
                SqlCommand cmd = new SqlCommand("INSERT INTO Appointments (CaregiverId, PatientId, AppointmentDate, Status) VALUES (@CaregiverId, @PatientId, @AppointmentDate, @Status)", conn);
                cmd.Parameters.AddWithValue("@CaregiverId", CaregiverId);
                cmd.Parameters.AddWithValue("@PatientId", PatientId);
                cmd.Parameters.AddWithValue("@AppointmentDate", AppointmentDate);
                cmd.Parameters.AddWithValue("@Status", "Scheduled");
                cmd.ExecuteNonQuery();

                // Create a notification for the scheduled appointment
                SqlCommand notificationCmd = new SqlCommand("INSERT INTO AppointmentNotifications (AppointmentId, NotificationMessage) VALUES (SCOPE_IDENTITY(), 'Appointment Scheduled')", conn);
                notificationCmd.ExecuteNonQuery();
            }

            return RedirectToPage();
        }

        // OnPost method to update an existing appointment
        public IActionResult OnPostUpdate(int AppointmentId, DateTime NewAppointmentDate)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                // Update appointment date
                SqlCommand cmd = new SqlCommand("UPDATE Appointments SET AppointmentDate = @NewAppointmentDate WHERE Id = @AppointmentId", conn);
                cmd.Parameters.AddWithValue("@AppointmentId", AppointmentId);
                cmd.Parameters.AddWithValue("@NewAppointmentDate", NewAppointmentDate);
                cmd.ExecuteNonQuery();

                // Create a notification for the appointment update
                SqlCommand notificationCmd = new SqlCommand("INSERT INTO AppointmentNotifications (AppointmentId, NotificationMessage) VALUES (@AppointmentId, 'Appointment Updated')", conn);
                notificationCmd.Parameters.AddWithValue("@AppointmentId", AppointmentId);
                notificationCmd.ExecuteNonQuery();
            }

            return RedirectToPage();
        }
    }
}
