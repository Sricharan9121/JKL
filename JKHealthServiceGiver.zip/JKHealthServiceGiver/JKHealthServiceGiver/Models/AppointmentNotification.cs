﻿public class AppointmentNotification
{
    public int Id { get; set; }             // Added Id property
    public int AppointmentId { get; set; }  // Added AppointmentId to link the notification to an appointment
    public string NotificationMessage { get; set; }  // Corrected Message property to NotificationMessage
    public DateTime CreatedAt { get; set; }
}
