﻿namespace JKHealthServiceGiver.Models
{
    public class Appointment
    {
        public int Id { get; set; }
        public int CaregiverId { get; set; }  // Foreign key to Caregiver
        public int PatientId { get; set; }    // Foreign key to Patient
        public string CaregiverName { get; set; }
        public string PatientName { get; set; }
        public DateTime AppointmentDate { get; set; }  // Correct property name
        public string Status { get; set; }
    }

}