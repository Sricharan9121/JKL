using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace JKHealthServiceGiver.Pages
{
    public class PatientDashboardModel : PageModel
    {
        private readonly string _connectionString = "Data Source=DESKTOP-QAPCFG3\\SQLEXPRESS;Initial Catalog=healthserviceprovider;Integrated Security=True";

        public List<Patient> Patients { get; set; } = new List<Patient>();

        public void OnGet()
        {
            // Fetch all patients from the database
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Patients", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Patients.Add(new Patient
                    {
                        Id = (int)reader["Id"],
                        Name = reader["Name"].ToString(),
                        Address = reader["Address"].ToString(),
                        MedicalRecords = reader["MedicalRecords"].ToString()
                    });
                }
            }
        }

        public IActionResult OnPostAdd(string Name, string Address, string MedicalRecords)
        {
            // Add a new patient to the database
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Patients (Name, Address, MedicalRecords) VALUES (@Name, @Address, @MedicalRecords)", conn);
                cmd.Parameters.AddWithValue("@Name", Name);
                cmd.Parameters.AddWithValue("@Address", Address);
                cmd.Parameters.AddWithValue("@MedicalRecords", MedicalRecords);
                cmd.ExecuteNonQuery();
            }
            return RedirectToPage();
        }

        public IActionResult OnPostRemove(int PatientId)
        {
            // Remove a patient from the database
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM Patients WHERE Id = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", PatientId);
                cmd.ExecuteNonQuery();
            }
            return RedirectToPage();
        }
    }

    public class Patient
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string MedicalRecords { get; set; }
    }
}
